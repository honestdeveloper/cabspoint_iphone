/**
 * To use GoogleMapsSDKDemos, please register an APIKey for your application
 * and set it here. Please see the README for more information. Your APIKey
 * should be kept private.
 */

static NSString *const kAPIKey = @"";
