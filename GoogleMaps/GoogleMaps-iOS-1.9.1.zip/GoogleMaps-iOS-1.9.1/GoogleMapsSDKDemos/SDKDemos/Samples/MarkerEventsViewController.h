#import <UIKit/UIKit.h>

#import <GoogleMaps/GoogleMaps.h>

@interface MarkerEventsViewController : UIViewController <GMSMapViewDelegate>

@end
