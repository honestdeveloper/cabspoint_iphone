#import <UIKit/UIKit.h>

#import <GoogleMaps/GoogleMaps.h>

@interface MarkerLayerViewController : UIViewController<GMSMapViewDelegate>

@end
